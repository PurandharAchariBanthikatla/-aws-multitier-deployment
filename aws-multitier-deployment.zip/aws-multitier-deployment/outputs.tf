output "vpc_id" {
  description = "ID of the created VPC"
  value       = module.vpc.vpc_id
}

output "web_instance_public_ip" {
  description = "Public IP address of the Web tier EC2 instance"
  value       = module.ec2.web_instance_public_ip
}

output "app_instance_private_ip" {
  description = "Private IP address of the App tier EC2 instance"
  value       = module.ec2.app_instance_private_ip
}

output "db_endpoint" {
  description = "Connection endpoint of the RDS database (if created)"
  value       = module.rds.db_endpoint
}

output "s3_bucket_name" {
  description = "Name of the S3 bucket used for static assets"
  value       = module.s3.bucket_name
}

output "web_security_group_id" {
  description = "ID of the Web tier security group"
  value       = module.security.web_sg_id
}
