locals {
  name_prefix = "${var.project_name}-${var.environment}"

  common_tags = {
    Project     = var.project_name
    Environment = var.environment
    ManagedBy   = "Terraform"
  }
}

# ---------------------------------------------------------------------------
# Networking - VPC, subnets, IGW, NAT, route tables
# ---------------------------------------------------------------------------
module "vpc" {
  source = "./modules/vpc"

  name_prefix              = local.name_prefix
  vpc_cidr                 = var.vpc_cidr
  public_subnet_cidr       = var.public_subnet_cidr
  private_app_subnet_cidr  = var.private_app_subnet_cidr
  private_db_subnet_cidr   = var.private_db_subnet_cidr
  private_db_subnet_cidr_2 = var.private_db_subnet_cidr_2
  availability_zones       = var.availability_zones
  tags                      = local.common_tags
}

# ---------------------------------------------------------------------------
# Security Groups - tier-to-tier isolation
# ---------------------------------------------------------------------------
module "security" {
  source = "./modules/security"

  name_prefix      = local.name_prefix
  vpc_id           = module.vpc.vpc_id
  ssh_allowed_cidr = var.ssh_allowed_cidr
  tags             = local.common_tags
}

# ---------------------------------------------------------------------------
# S3 - static asset storage
# ---------------------------------------------------------------------------
module "s3" {
  source = "./modules/s3"

  name_prefix = local.name_prefix
  bucket_name = var.s3_bucket_name
  tags        = local.common_tags
}

# ---------------------------------------------------------------------------
# IAM - least-privilege roles & instance profiles
# ---------------------------------------------------------------------------
module "iam" {
  source = "./modules/iam"

  name_prefix    = local.name_prefix
  s3_bucket_arn  = module.s3.bucket_arn
  tags           = local.common_tags
}

# ---------------------------------------------------------------------------
# EC2 - Web tier (public subnet) & App tier (private subnet)
# ---------------------------------------------------------------------------
module "ec2" {
  source = "./modules/ec2"

  name_prefix             = local.name_prefix
  public_subnet_id        = module.vpc.public_subnet_id
  private_app_subnet_id   = module.vpc.private_app_subnet_id
  web_sg_id               = module.security.web_sg_id
  app_sg_id               = module.security.app_sg_id
  web_instance_type       = var.web_instance_type
  app_instance_type       = var.app_instance_type
  key_name                = var.key_name
  web_instance_profile    = module.iam.web_instance_profile_name
  app_instance_profile    = module.iam.app_instance_profile_name
  s3_bucket_name          = module.s3.bucket_name
  tags                    = local.common_tags
}

# ---------------------------------------------------------------------------
# RDS - Database tier (private subnets, multi-AZ subnet group)
# ---------------------------------------------------------------------------
module "rds" {
  source = "./modules/rds"

  create_rds              = var.create_rds
  name_prefix             = local.name_prefix
  private_db_subnet_id    = module.vpc.private_db_subnet_id
  private_db_subnet_id_2  = module.vpc.private_db_subnet_id_2
  db_sg_id                = module.security.db_sg_id
  db_engine               = var.db_engine
  db_engine_version       = var.db_engine_version
  db_instance_class       = var.db_instance_class
  db_name                 = var.db_name
  db_username             = var.db_username
  db_password             = var.db_password
  db_allocated_storage    = var.db_allocated_storage
  tags                    = local.common_tags
}
