variable "create_rds" {
  description = "Whether to create the RDS instance"
  type        = bool
  default     = true
}

variable "name_prefix" {
  description = "Prefix used for naming resources"
  type        = string
}

variable "private_db_subnet_id" {
  description = "ID of the first private DB subnet"
  type        = string
}

variable "private_db_subnet_id_2" {
  description = "ID of the second private DB subnet (different AZ)"
  type        = string
}

variable "db_sg_id" {
  description = "Security group ID for the DB tier"
  type        = string
}

variable "db_engine" {
  description = "Database engine"
  type        = string
  default     = "mysql"
}

variable "db_engine_version" {
  description = "Database engine version"
  type        = string
  default     = "8.0"
}

variable "db_instance_class" {
  description = "RDS instance class"
  type        = string
  default     = "db.t3.micro"
}

variable "db_name" {
  description = "Name of the initial database"
  type        = string
  default     = "appdb"
}

variable "db_username" {
  description = "Master username"
  type        = string
  default     = "admin"
}

variable "db_password" {
  description = "Master password"
  type        = string
  sensitive   = true
}

variable "db_allocated_storage" {
  description = "Allocated storage in GB"
  type        = number
  default     = 20
}

variable "tags" {
  description = "Common tags to apply to all resources"
  type        = map(string)
  default     = {}
}
