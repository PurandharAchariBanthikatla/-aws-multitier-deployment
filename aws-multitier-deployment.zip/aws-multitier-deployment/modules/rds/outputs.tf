output "db_endpoint" {
  description = "Connection endpoint of the RDS instance (empty if create_rds is false)"
  value       = var.create_rds ? aws_db_instance.main[0].endpoint : ""
}

output "db_instance_id" {
  description = "ID of the RDS instance (empty if create_rds is false)"
  value       = var.create_rds ? aws_db_instance.main[0].id : ""
}
