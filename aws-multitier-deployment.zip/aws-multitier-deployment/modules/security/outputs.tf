output "web_sg_id" {
  description = "ID of the Web tier security group"
  value       = aws_security_group.web.id
}

output "app_sg_id" {
  description = "ID of the App tier security group"
  value       = aws_security_group.app.id
}

output "db_sg_id" {
  description = "ID of the DB tier security group"
  value       = aws_security_group.db.id
}
