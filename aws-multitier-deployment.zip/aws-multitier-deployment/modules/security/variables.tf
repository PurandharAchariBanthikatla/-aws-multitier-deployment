variable "name_prefix" {
  description = "Prefix used for naming resources"
  type        = string
}

variable "vpc_id" {
  description = "ID of the VPC the security groups belong to"
  type        = string
}

variable "ssh_allowed_cidr" {
  description = "CIDR block allowed to SSH into the Web tier"
  type        = string
  default     = "0.0.0.0/0"
}

variable "app_port" {
  description = "Port the application tier listens on"
  type        = number
  default     = 8080
}

variable "db_port" {
  description = "Port the database tier listens on (3306 for MySQL, 5432 for Postgres)"
  type        = number
  default     = 3306
}

variable "tags" {
  description = "Common tags to apply to all resources"
  type        = map(string)
  default     = {}
}
