variable "name_prefix" {
  description = "Prefix used for naming resources"
  type        = string
}

variable "s3_bucket_arn" {
  description = "ARN of the S3 bucket the web role should be able to read from"
  type        = string
}

variable "tags" {
  description = "Common tags to apply to all resources"
  type        = map(string)
  default     = {}
}
