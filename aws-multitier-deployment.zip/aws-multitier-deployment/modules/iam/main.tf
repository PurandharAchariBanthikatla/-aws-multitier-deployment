# ---------------------------------------------------------------------------
# Trust policy - allows EC2 to assume these roles
# ---------------------------------------------------------------------------
data "aws_iam_policy_document" "ec2_assume_role" {
  statement {
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["ec2.amazonaws.com"]
    }
  }
}

# ---------------------------------------------------------------------------
# Web Tier Role - read-only access to the static assets S3 bucket
# ---------------------------------------------------------------------------
resource "aws_iam_role" "web_role" {
  name               = "${var.name_prefix}-web-role"
  assume_role_policy = data.aws_iam_policy_document.ec2_assume_role.json

  tags = merge(var.tags, {
    Name = "${var.name_prefix}-web-role"
  })
}

data "aws_iam_policy_document" "web_s3_read" {
  statement {
    sid     = "ReadStaticAssets"
    effect  = "Allow"
    actions = [
      "s3:GetObject",
      "s3:ListBucket",
    ]
    resources = [
      var.s3_bucket_arn,
      "${var.s3_bucket_arn}/*",
    ]
  }
}

resource "aws_iam_role_policy" "web_s3_read" {
  name   = "${var.name_prefix}-web-s3-read"
  role   = aws_iam_role.web_role.id
  policy = data.aws_iam_policy_document.web_s3_read.json
}

# Allow AWS Systems Manager Session Manager access (no SSH keys required)
resource "aws_iam_role_policy_attachment" "web_ssm" {
  role       = aws_iam_role.web_role.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"
}

resource "aws_iam_instance_profile" "web_profile" {
  name = "${var.name_prefix}-web-profile"
  role = aws_iam_role.web_role.name
}

# ---------------------------------------------------------------------------
# App Tier Role - read access to SSM Parameter Store for DB credentials
# ---------------------------------------------------------------------------
resource "aws_iam_role" "app_role" {
  name               = "${var.name_prefix}-app-role"
  assume_role_policy = data.aws_iam_policy_document.ec2_assume_role.json

  tags = merge(var.tags, {
    Name = "${var.name_prefix}-app-role"
  })
}

data "aws_iam_policy_document" "app_ssm_params" {
  statement {
    sid    = "ReadDbParameters"
    effect = "Allow"
    actions = [
      "ssm:GetParameter",
      "ssm:GetParameters",
      "ssm:GetParametersByPath",
    ]
    resources = [
      "arn:aws:ssm:*:*:parameter/${var.name_prefix}/*",
    ]
  }
}

resource "aws_iam_role_policy" "app_ssm_params" {
  name   = "${var.name_prefix}-app-ssm-read"
  role   = aws_iam_role.app_role.id
  policy = data.aws_iam_policy_document.app_ssm_params.json
}

resource "aws_iam_role_policy_attachment" "app_ssm" {
  role       = aws_iam_role.app_role.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"
}

resource "aws_iam_instance_profile" "app_profile" {
  name = "${var.name_prefix}-app-profile"
  role = aws_iam_role.app_role.name
}
