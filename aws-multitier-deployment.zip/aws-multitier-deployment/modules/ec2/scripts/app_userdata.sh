#!/bin/bash
# Bootstrap script for the App tier instance
set -euo pipefail

dnf update -y
dnf install -y java-17-amazon-corretto

# Placeholder: in a real deployment, fetch the app artifact (e.g. from S3 or
# a package repo), and run it as a systemd service. Example:
#
#   aws s3 cp s3://my-app-artifacts/app.jar /opt/app/app.jar
#   java -jar /opt/app/app.jar --server.port=8080 &

echo "App tier instance bootstrapped" > /var/log/app-bootstrap.log
