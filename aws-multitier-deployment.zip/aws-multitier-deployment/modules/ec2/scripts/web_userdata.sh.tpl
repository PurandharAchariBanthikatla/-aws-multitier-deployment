#!/bin/bash
# Bootstrap script for the Web tier instance
set -euo pipefail

dnf update -y
dnf install -y httpd aws-cli

systemctl enable httpd
systemctl start httpd

# Simple landing page that confirms the deployment and S3 bucket name
cat > /var/www/html/index.html <<EOF
<!DOCTYPE html>
<html>
  <head><title>Multi-Tier App - Web Tier</title></head>
  <body>
    <h1>Web Tier is running</h1>
    <p>Static assets bucket: ${s3_bucket_name}</p>
  </body>
</html>
EOF

# Example: sync static assets from S3 on boot (requires the web IAM role)
# aws s3 sync s3://${s3_bucket_name}/ /var/www/html/assets/
