# ---------------------------------------------------------------------------
# Latest Amazon Linux 2023 AMI
# ---------------------------------------------------------------------------
data "aws_ami" "amazon_linux" {
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = ["al2023-ami-*-x86_64"]
  }

  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

# ---------------------------------------------------------------------------
# Web Tier Instance (public subnet)
# ---------------------------------------------------------------------------
resource "aws_instance" "web" {
  ami                         = data.aws_ami.amazon_linux.id
  instance_type               = var.web_instance_type
  subnet_id                   = var.public_subnet_id
  vpc_security_group_ids      = [var.web_sg_id]
  iam_instance_profile        = var.web_instance_profile
  key_name                    = var.key_name != "" ? var.key_name : null
  associate_public_ip_address = true

  user_data = templatefile("${path.module}/scripts/web_userdata.sh.tpl", {
    s3_bucket_name = var.s3_bucket_name
  })

  tags = merge(var.tags, {
    Name = "${var.name_prefix}-web"
    Tier = "web"
  })
}

# ---------------------------------------------------------------------------
# App Tier Instance (private subnet)
# ---------------------------------------------------------------------------
resource "aws_instance" "app" {
  ami                    = data.aws_ami.amazon_linux.id
  instance_type          = var.app_instance_type
  subnet_id              = var.private_app_subnet_id
  vpc_security_group_ids = [var.app_sg_id]
  iam_instance_profile   = var.app_instance_profile
  key_name               = var.key_name != "" ? var.key_name : null

  user_data = file("${path.module}/scripts/app_userdata.sh")

  tags = merge(var.tags, {
    Name = "${var.name_prefix}-app"
    Tier = "application"
  })
}
