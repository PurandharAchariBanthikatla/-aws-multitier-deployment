variable "name_prefix" {
  description = "Prefix used for naming resources"
  type        = string
}

variable "public_subnet_id" {
  description = "ID of the public subnet for the Web tier"
  type        = string
}

variable "private_app_subnet_id" {
  description = "ID of the private subnet for the App tier"
  type        = string
}

variable "web_sg_id" {
  description = "Security group ID for the Web tier"
  type        = string
}

variable "app_sg_id" {
  description = "Security group ID for the App tier"
  type        = string
}

variable "web_instance_type" {
  description = "Instance type for the Web tier"
  type        = string
  default     = "t2.micro"
}

variable "app_instance_type" {
  description = "Instance type for the App tier"
  type        = string
  default     = "t2.micro"
}

variable "key_name" {
  description = "Name of an existing EC2 Key Pair for SSH access (optional)"
  type        = string
  default     = ""
}

variable "web_instance_profile" {
  description = "IAM instance profile name for the Web tier"
  type        = string
}

variable "app_instance_profile" {
  description = "IAM instance profile name for the App tier"
  type        = string
}

variable "s3_bucket_name" {
  description = "Name of the S3 bucket for static assets (passed to web user-data)"
  type        = string
}

variable "tags" {
  description = "Common tags to apply to all resources"
  type        = map(string)
  default     = {}
}
