output "web_instance_id" {
  description = "Instance ID of the Web tier EC2 instance"
  value       = aws_instance.web.id
}

output "web_instance_public_ip" {
  description = "Public IP address of the Web tier EC2 instance"
  value       = aws_instance.web.public_ip
}

output "app_instance_id" {
  description = "Instance ID of the App tier EC2 instance"
  value       = aws_instance.app.id
}

output "app_instance_private_ip" {
  description = "Private IP address of the App tier EC2 instance"
  value       = aws_instance.app.private_ip
}
