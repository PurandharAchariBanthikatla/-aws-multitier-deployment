variable "name_prefix" {
  description = "Prefix used for naming resources"
  type        = string
}

variable "bucket_name" {
  description = "Globally unique S3 bucket name. If empty, a unique name is generated."
  type        = string
  default     = ""
}

variable "tags" {
  description = "Common tags to apply to all resources"
  type        = map(string)
  default     = {}
}
