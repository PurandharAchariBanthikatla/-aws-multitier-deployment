variable "aws_region" {
  description = "AWS region to deploy resources into"
  type        = string
  default     = "ap-south-1"
}

variable "project_name" {
  description = "Project name used for tagging and naming resources"
  type        = string
  default     = "multitier-app"
}

variable "environment" {
  description = "Environment name (e.g. dev, staging, prod)"
  type        = string
  default     = "dev"
}

# ---------- Networking ----------

variable "vpc_cidr" {
  description = "CIDR block for the VPC"
  type        = string
  default     = "10.0.0.0/16"
}

variable "public_subnet_cidr" {
  description = "CIDR block for the public subnet (Web tier)"
  type        = string
  default     = "10.0.1.0/24"
}

variable "private_app_subnet_cidr" {
  description = "CIDR block for the private subnet (App tier)"
  type        = string
  default     = "10.0.2.0/24"
}

variable "private_db_subnet_cidr" {
  description = "CIDR block for the private subnet (DB tier)"
  type        = string
  default     = "10.0.3.0/24"
}

variable "private_db_subnet_cidr_2" {
  description = "CIDR block for the second private DB subnet (required for RDS subnet group, must be in a different AZ)"
  type        = string
  default     = "10.0.4.0/24"
}

variable "availability_zones" {
  description = "List of availability zones to use"
  type        = list(string)
  default     = ["ap-south-1a", "ap-south-1b"]
}

# ---------- EC2 ----------

variable "key_name" {
  description = "Name of an existing EC2 Key Pair for SSH access"
  type        = string
  default     = "" # set this in terraform.tfvars
}

variable "web_instance_type" {
  description = "Instance type for the Web tier"
  type        = string
  default     = "t2.micro"
}

variable "app_instance_type" {
  description = "Instance type for the App tier"
  type        = string
  default     = "t2.micro"
}

variable "ssh_allowed_cidr" {
  description = "CIDR block allowed to SSH into the Web tier instance"
  type        = string
  default     = "0.0.0.0/0" # NOTE: restrict this to your own IP in production, e.g. 1.2.3.4/32
}

# ---------- RDS ----------

variable "create_rds" {
  description = "Whether to create the RDS database tier (set to false to avoid costs while testing)"
  type        = bool
  default     = true
}

variable "db_engine" {
  description = "Database engine for RDS"
  type        = string
  default     = "mysql"
}

variable "db_engine_version" {
  description = "Database engine version"
  type        = string
  default     = "8.0"
}

variable "db_instance_class" {
  description = "RDS instance class"
  type        = string
  default     = "db.t3.micro"
}

variable "db_name" {
  description = "Name of the initial database to create"
  type        = string
  default     = "appdb"
}

variable "db_username" {
  description = "Master username for the database"
  type        = string
  default     = "admin"
}

variable "db_password" {
  description = "Master password for the database"
  type        = string
  sensitive   = true
  default     = "" # set this in terraform.tfvars - never commit real values
}

variable "db_allocated_storage" {
  description = "Allocated storage for RDS instance (in GB)"
  type        = number
  default     = 20
}

# ---------- S3 ----------

variable "s3_bucket_name" {
  description = "Globally unique name for the static assets S3 bucket"
  type        = string
  default     = "" # if empty, a unique name is generated automatically
}
